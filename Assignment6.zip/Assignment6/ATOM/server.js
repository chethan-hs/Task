var express = require("express");
const sqlite3 = require('sqlite3').verbose();
var app = express();
bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json()); 

const expressValidator = require('express-validator');
 

var routes = require('./api/routes/AssignmentRoutes'); //importing route
routes(app); //register the route

app.listen(3000, () => {
    var assignmentDataProvider = require('./api/dataProvider/AssignmentDataProvider'); 
    assignmentDataProvider.createTable();     
    console.log("Server running on port 3000");
});