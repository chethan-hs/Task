
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ClientRequestProcessor { 
	
	/**
	 * @param fileName
	 */
	public void start(String fileName) {
		ServerSocket serverSocket = null;
		Socket clientSocket = null;

		try {
			serverSocket = new ServerSocket(TextProviderConstants.PORT);
			ExecutorService executer = 
					Executors.newFixedThreadPool(TextProviderConstants.PROCESSOR_COUNT);
		    System.out.println("TextProvider started...");
			while (true) {
				try {
					// Waiting for client 
					clientSocket = serverSocket.accept();				 
				} catch (IOException e) {
					// When client request to Shutdown the server, it throws exception.
					executer.shutdown();
					System.out.println("Server shut down.");
					System.exit(0);
				}
				// Create new task to server the client.
				RequestProcessingTask requestProcessorTask =
						new RequestProcessingTask(serverSocket, clientSocket, fileName);
				executer.execute(requestProcessorTask);
			}

		} catch (IOException e) {
			e.printStackTrace();
		}  
	}
}
