public class TextProviderConstants {
	
	public static final int PORT = 10322;
	public static final int PROCESSOR_COUNT = 5;
	public static final int CHUNCK_COUNT = 4;
	public static final String ERROR = "ERR";
	public static final String OK = "OK";	
	public static final String NEXT_LINE = "\n\r";
	public static final String COMMAND_QUIT = "QUIT";
	public static final String COMMAND_SHUTDOWN = "SHUTDOWN";
	public static final String COMMAND_GET = "GET";
	public static final int SIZE_1MB = 1024 * 1024;
	public static final int SIZE_5MB =  5 * SIZE_1MB;
	public static final int SIZE_10MB =  10 * SIZE_1MB;
	public static final int SIZE_250MB =  250 * SIZE_1MB;
 
	 
	 

}
