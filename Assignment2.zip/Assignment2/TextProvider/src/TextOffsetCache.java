import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList; 
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Stream;

public class TextOffsetCache {

	private static long[] offsetArray;

	public static void main(String[] args) {
		createCache("resource/a.txt");
	}

	public static int offsetSize() {
		return offsetArray.length-1;
	}

	/**
	 * @param lineNumber
	 * @return
	 */
	public static long getLineOffset(int lineNumber) {
		long offset = offsetArray[lineNumber-1];
		return offset;
	} 

	/**
	 * @param fileName
	 */
	public static void createCache(String fileName) {
		float fileSizeInGB = getFileLengthInGB(fileName);		 
		if(fileSizeInGB >  25) { 
			createCacheForBigFile(fileName);			 
		}else { 
			createCacheForSmallFile(fileName);
		}
	}

	/**
	 * @param fileName
	 */
	public static void createCacheForBigFile(String fileName) {
		System.out.println("Creating offest cache for the lines of the file:"+fileName);
		long startTime = System.currentTimeMillis(); 	

		System.out.println("Getting line count for the file:"+fileName);
		int lineCount = getLineCount(fileName);
		System.out.println("Total Number of line = "+lineCount);
		offsetArray = new long[lineCount+1];

		System.out.println("Creating Chunks...");
		int linesPerChunk = lineCount/TextProviderConstants.CHUNCK_COUNT;
		int start = 1;
		int end = 0;
		List<Chunk> chunkList = new ArrayList<Chunk>();
		while(true) {			
			if( (lineCount - (start+ linesPerChunk-1)) >= linesPerChunk) {
				end = start + linesPerChunk-1;
				Chunk chunk = new Chunk(start, end);
				chunkList.add(chunk);
				start = end+1;
			}else {
				Chunk chunk = new Chunk(start, lineCount);
				chunkList.add(chunk);
				break;
			}
		}

		chunkList.forEach(
				chunk -> 
				{System.out.println("Chunk start="+chunk.getStart() +", Chunk end = "+chunk.getEnd());});
		System.out.println("Completed creating Chunks...");


		CountDownLatch latch = new CountDownLatch(chunkList.size()); 
		ExecutorService executer = 
				Executors.newFixedThreadPool(chunkList.size());

		// Set 0 as offset for first line.
		offsetArray[0] = 0;
		System.out.println("Starting processing chunks...");
		for(Chunk chunk: chunkList) {
			CacheCreateTask cacheCreateTask = new CacheCreateTask(fileName, chunk, 
					offsetArray, latch);
			executer.execute(cacheCreateTask);
		}
		try {
			// Wait for all the threads to complete their task.
			System.out.println("Waiting for threads to complete the process...");
			latch.await();			

		} catch (InterruptedException e) {			 
			e.printStackTrace();
		} 
		System.out.println("Completed processing chunks ...");

		System.out.println("Performing offset post processing task...");
		long lastOffset = chunkList.get(0).getLastOffset();
		for(int i=1; i<chunkList.size(); i++) {
			Chunk chunk = chunkList.get(i);
			for(int j=chunk.getStart(); j<=chunk.getEnd(); j++) {
				offsetArray[j]+=lastOffset;				
			}
			lastOffset+=chunk.getLastOffset();
		}
		System.out.println("Completed performing offset post processing task...");
		executer.shutdown();
		long endTime = System.currentTimeMillis();
		System.out.println("Completed creating offest cache.");
		System.out.println(
				"Total time taken to create cache:" + ((endTime - startTime) / 1000)+" seconds." );	 
	}

	/**
	 * @param fileName
	 */
	public static void createCacheForSmallFile(String fileName) {
		System.out.println("Creating offest cache for the lines of the file:"+fileName);	 	 
		long startTime = System.currentTimeMillis();

		int lineCount = getLineCount(fileName);
		System.out.println("Total Number of line = "+lineCount);
		offsetArray = new long[lineCount+1];		 

		// Process 10 MB at a time 
		int bufferSize = TextProviderConstants.SIZE_10MB;		 
		int lineSeparatorLength = System.getProperty("line.separator").length();
		// offset of first line.
		long lineOffset = 0; 
		int index = 0;
		offsetArray[index++] = lineOffset;
		try (BufferedReader bufferedReader = new BufferedReader(new FileReader(fileName), bufferSize)){		 
			String line = bufferedReader.readLine();			 
			while (line != null) {
				// offset of second line onwards
				lineOffset += line.length() + lineSeparatorLength;  
				offsetArray[index++] = lineOffset;				 
				line = bufferedReader.readLine();
			}
		} catch (IOException ioe) {
			System.err.println("Error: " + ioe.getMessage());
		}	 
		long endTime = System.currentTimeMillis();
		System.out.println("Completed creating offest cache.");
		System.out.println(
				"Total time taken to create cache:" + ((endTime - startTime) / 1000)+" seconds." );
		System.out.println("Total Number of records in the cache:" + (offsetArray.length-1));		 
	}


	/**
	 * @param fileName
	 * @return
	 */
	private static int getLineCount(String fileName) {
		File file = new File(fileName);
		int count = 0;
		try (Stream<String> linesStream = Files.lines(file.toPath())) {
			count = (int)linesStream.parallel().count();
		} catch (IOException e) {			 
			e.printStackTrace();
		}
		return count;
	}
	
	/**
	 * @param fileName
	 * @return
	 */
	public static float getFileLengthInGB(String fileName) {	 		
		int fileSizeInMB =  getFileLengthInMB(fileName);	
		float fileSizeInGB = fileSizeInMB/(1.0f * 1024); 
		System.out.println("File size in GB="+ fileSizeInGB);	
		return fileSizeInGB;
	}

	/**
	 * @param fileName
	 * @return
	 */
	public static int getFileLengthInMB(String fileName) {	 		
		long fileSizeInBytes =  getFileLengthInBytes(fileName);	
		int fileSizeInMB = (int)(fileSizeInBytes/(1 * 1024 * 1024));	 
		System.out.println("File size in MB="+ fileSizeInMB);	
		return fileSizeInMB;
	}

	/**
	 * @param fileName
	 * @return
	 */
	public static long getFileLengthInBytes(String fileName) {		
		java.io.File f = new java.io.File(fileName);		
		long fileSizeInBytes = f.length();	 
		System.out.println("File size in fileSizeInBytes="+ fileSizeInBytes);	
		return 	fileSizeInBytes;		
	} 
}

class Chunk{
	// start line number
	private int start;
	// End line number
	private int end;
	// offset of last line
	private long lastOffset;

	Chunk(int start, int end){
		this.start = start;
		this.end = end;
	}

	public long getLastOffset() {
		return lastOffset;
	}

	public void setLastOffset(long lastOffset) {
		this.lastOffset = lastOffset;
	}

	public int getStart() {
		return start;
	}

	public void setStart(int start) {
		this.start = start;
	}

	public int getEnd() {
		return end;
	}

	public void setEnd(int end) {
		this.end = end;
	}

}

class CacheCreateTask implements Runnable{	
	Chunk chunk;
	private CountDownLatch latch; 
	long[] offsetArray;
	String fileName;


	CacheCreateTask(String fileName, Chunk chunk, 
			long[] offsetArray, CountDownLatch latch) {
		this.chunk = chunk;
		this.latch = latch;
		this.offsetArray = offsetArray;
		this.fileName =fileName;
	}

	public void run() {
		// Process 10 MB at a time 
		int bufferSize = TextProviderConstants.SIZE_10MB;
		try (BufferedReader bufferedReader = new BufferedReader(new FileReader(fileName), bufferSize)) {
			long count = 0;
			// Skip the lines until we get the specified start line number
			long skipTarget = chunk.getStart()-1;
			while(count != skipTarget) {
				bufferedReader.readLine();
				count++;
			}
			int lineSeparatorLength = System.getProperty("line.separator").length();
			String line;
			int lineOffset = 0;
			int startIndex = chunk.getStart();
			// Process the lines from specified start to end line number.
			while(count != chunk.getEnd()) {
				line = bufferedReader.readLine();	    		 
				lineOffset += line.length() + lineSeparatorLength;  
				offsetArray[startIndex++] = lineOffset;				 
				count++;
			}
			chunk.setLastOffset(offsetArray[chunk.getEnd()]);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		latch.countDown();
	}
}
