import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class RequestProcessingTask implements Runnable {

	private ServerSocket serverSocket;
	private Socket clientSocket;
	private String fileName;

	/**
	 * @param serverSocket
	 * @param clientSocket
	 * @param fileName
	 */
	public RequestProcessingTask(ServerSocket serverSocket,
			Socket clientSocket,
			String fileName) {
		this.serverSocket = serverSocket;
		this.clientSocket = clientSocket;
		this.fileName = fileName;
	}

	public void run() {
		InputStream inputStream = null;
		BufferedReader bufferedReader = null;
		DataOutputStream dataOutputStream = null;
		try {
			inputStream = clientSocket.getInputStream();
			bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
			dataOutputStream = new DataOutputStream(clientSocket.getOutputStream());
		} catch (IOException e) {
			e.printStackTrace();
			return;
		}
		String command;
		while (true) {
			try {
				// Read the user requested command
				dataOutputStream.writeBytes("--> ");
				dataOutputStream.flush();
				command = bufferedReader.readLine();
				String response = null;
				if (TextProviderConstants.COMMAND_QUIT.equalsIgnoreCase(command)) {
					clientSocket.close();
					return;
				} else if (TextProviderConstants.COMMAND_SHUTDOWN.equalsIgnoreCase(command)) {
					System.out.println("Shuting down server.");
					clientSocket.close();
					serverSocket.close();
					return;
				} else {

					if (command != null) {
						String[] fields = command.split(" ");
						String operation = fields[0];
						if (TextProviderConstants.COMMAND_GET.equalsIgnoreCase(operation)) {
							if (fields.length != 2) {
								response = TextProviderConstants.ERROR;
							} else {
								int lineNumber = 0;
								try {
									lineNumber = Integer.parseInt(fields[1]);
									response = TextFetcher.readText(fileName, lineNumber);
								} catch (NumberFormatException e) {
									response = TextProviderConstants.ERROR;
								}
							}
						} else {
							response = TextProviderConstants.ERROR;
						}
					}
				}

				if(!response.equalsIgnoreCase(TextProviderConstants.ERROR)) {
					dataOutputStream.writeBytes("<-- "+
							TextProviderConstants.OK + TextProviderConstants.NEXT_LINE);
				}				 
				dataOutputStream.writeBytes("<-- "+ response + TextProviderConstants.NEXT_LINE);				 
				dataOutputStream.flush();

			} catch (IOException e) {
				e.printStackTrace();
				return;
			}
		}
	}
}
