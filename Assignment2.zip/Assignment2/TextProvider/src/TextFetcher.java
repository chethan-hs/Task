import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class TextFetcher {
	
	public static String readText(String fileName, int lineNumber) {

		if (lineNumber <= 0 || lineNumber >= TextOffsetCache.offsetSize()) {
			// System.out.println("Invalid line number:"+ lineNumber );
			return TextProviderConstants.ERROR;
		}
		
		long offset = TextOffsetCache.getLineOffset(lineNumber);
		// System.out.println("offset for line number:"+ offset );
		File readFile = new File(fileName);
		RandomAccessFile randomAccessFile = null;
		try {
			randomAccessFile = new RandomAccessFile(readFile, "r");
			try {

				randomAccessFile.seek(offset);
				String text = randomAccessFile.readLine();
				// System.out.println(text);
				return text;

			} catch (IOException e) {
				e.printStackTrace();
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (randomAccessFile != null) {
				try {
					randomAccessFile.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return TextProviderConstants.ERROR;
	}

}
