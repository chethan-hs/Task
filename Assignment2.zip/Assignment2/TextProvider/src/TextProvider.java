import java.io.File;
/*
 * Text Provider entry point.
 */
public class TextProvider {

	public static void main(String[] args) {
 
		if(args == null || args.length ==0) {
			 System.err.println("Please provide the file path.");
		     return;
		}
		String fileName = args[0];	    
	    
	    // Return if file not exist 
	    File f = new File(fileName);
	    if(! (f.exists() && !f.isDirectory())) { 
	        System.err.println("File " + fileName+ " not found");
	        return;
	    }
	    
	    // If the file exist, then create the offset cache for each line in the file.
	    TextOffsetCache.createCache(fileName);
	    
	    // Start the ClientRequestProcessor
	    ClientRequestProcessor clientRequestProcessor = new ClientRequestProcessor();
	    clientRequestProcessor.start(fileName);
	}
}
