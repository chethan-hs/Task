#!/bin/bash

ant build -buildfile ./ant/build.xml
