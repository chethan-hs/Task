1. Walkthrough of the system's architecture

     a. System takes the file path as parameter during starting the system.
     b. Then it creates the cache of offset for each line in the file. If the file size is more than 25 GB, then is uses threads to create 
         the cache, so that it can process the file parallelly.
   
         Array data structure is used to store the offset of each line. Offset of first line is stored in 0th(zero th)
         index, offset of second line is stored in 1st index and so on...  offset of nth line is stored in the index n-1.

        Assumption: Maximum number of lines in the file is in the range of int. i.e. max line count is: 2,147,483, 647

        If the number of lines exceeds the int max range, then we need to use different data structure like map which is not taken care.

     c. Once cache is created, system is ready to serve the requests.

     d. When client requests for 5th line, then the system gets the 5th line offset from the cache(Array) 
         which is stored at index 4, then it opens the file read mode and directly go to the offset and fetch the
         text and returns to the client. It uses  RandomAccessFile.seek() function to directly go to specified offset.

     e. Currently the system is configured in the constants file:TextProviderConstants.java to serve 5 clients concurrently. 
         We can change this value as per the need.

        	public static final int PROCESSOR_COUNT = 5;

    
2.  Tested with 10 GB file(356,089,413 lines) by keeping minimum heap space 2 GB and max heap space 4GB using gnu Linux , system 
     is taking 180 to 200 seconds to cache the offset during the system start-up.  Once the system is up, it serves the request very fast. 


3. Ant is used to compile the files.



 