#!/bin/bash

cd bin

filename=$1

if [ -z "$filename" ]; then
   echo "Please provide the filepath as argument";
   exit 1
fi

java TextProvider  $filename
