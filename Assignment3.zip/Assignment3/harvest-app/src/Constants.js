export const SERVER = 'http://localhost:5000';
export const GET_FI_LIST_URL = SERVER + '/api/v1/financial-institutions';
export const LOGIN_URL = SERVER + '/api/v1/account/login';
export const GET_MFA_REQUEST_URL = SERVER + '/api/v1/mfa-request/';
export const PUT_MFA_RESPONSE_URL = SERVER + '/api/v1/mfa-response';
export const SEND_USER_MESSAGE_URL = SERVER + '/api/v1/user-message';
export const GET_AGENT_MESSAGE_URL = SERVER + '/api/v1/agent-message/';
export const MAX_RETRY_COUNT = 5;


 
