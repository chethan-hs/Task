import React, { Component } from 'react';
import { Container, Row, Col, Navbar, NavbarBrand, Button, Label, Input, Spinner } from "reactstrap";
import { executeRestRequest } from './RestService';
import * as Constants from './Constants';


class App extends Component {

  constructor(props, context) {
    super(props, context);
    this.state = {
      email: null,
      password: null,
      fi_data: [],
      selected_fi: null,
      step: "start",
      request_id: null,
      show_spinner: false,
      show_message_spinner: false,
      agent_message: null,
      error_message: null
    }

    this.get_fi_list = this.get_fi_list.bind(this);
    this.start_chat = this.start_chat.bind(this);
    this.login = this.login.bind(this);
    this.sleep = this.sleep.bind(this);
    this.send_token = this.send_token.bind(this);
    this.send_message = this.send_message.bind(this);
    this.get_agent_message = this.get_agent_message.bind(this);
    this.stop_chat = this.stop_chat.bind(this);
    this.set_scroll_height = this.set_scroll_height.bind(this);
  }

  componentDidMount() {
    this.get_fi_list()
  }


  async get_fi_list() {
    var getFiListRequest = {
      url: Constants.GET_FI_LIST_URL,
      method: 'GET'
    }
    var getFiListResponse = await executeRestRequest(getFiListRequest);
    //  alert("Response="+JSON.stringify(getFiListResponse));  
    this.setState({ fi_data: getFiListResponse.data })
    // alert(JSON.stringify(this.state.fi_data));
  }



  start_chat(fi_name) {

    var fi_list = this.state.fi_data;
    for (var i = 0; i < fi_list.length; i++) {
      var data = fi_list[i]
      if (data.name == fi_name) {
        this.state.selected_fi = data;
        break;
      }
    }
    this.setState({ step: "login" })
    this.setState({ error_message: null })
  }




  async login() {

    var payload = new Object();
    var data = new Object();

    var email = this.state.email;
    var password = this.state.password;
    if (email == null || email.trim() == "" || password == null || password.trim() == "") {
      return;
    }

    this.setState({ show_spinner: true });
    data.email = email;
    data.password = password;
    var selected_fi = this.state.selected_fi
    data.fi_name = selected_fi.name
    payload.data = data;
    var loginRequest = {
      url: Constants.LOGIN_URL,
      method: 'POST',
      payload: payload
    }

    var loginResponse = await executeRestRequest(loginRequest);
    var responseData = loginResponse.data;
    this.state.request_id = responseData.request_id


    if (selected_fi.isMFA == true) {
      var getMfaRequest = {
        url: Constants.GET_MFA_REQUEST_URL + this.state.request_id,
        method: 'GET',
      }

      var getMfaResponse = await executeRestRequest(getMfaRequest);
      responseData = getMfaResponse.data
      var retryCount = 0;
      while (responseData.status == 'in-progress') {
        if (retryCount == Constants.MAX_RETRY_COUNT) {
          this.state.show_spinner = false;
          this.setState({ step: "start" })
          this.setState({ selected_fi: null })
          this.setState({ request_id: null })
          this.setState({ agent_message: null })
          this.setState({ error_message: "Technically difficulty. Please start chat again." })
          return;
        }
        await this.sleep(5000);
        getMfaResponse = await executeRestRequest(getMfaRequest);
        responseData = getMfaResponse.data
        retryCount++;
      }
      this.state.show_spinner = false;
      this.setState({ step: "authenticate" })
    }

  }


  async send_token() {
    this.setState({ show_spinner: true });
    var payload = new Object();
    var data = new Object();
    var token_id = document.getElementById('token').value;
    data.token_id = token_id;
    data.request_id = this.state.request_id;
    payload.data = data;

    var putMFARequest = {
      url: Constants.PUT_MFA_RESPONSE_URL,
      method: 'POST',
      payload: payload
    }
    var putMFAResponse = await executeRestRequest(putMFARequest);
    var responseData = putMFAResponse.data

    var getMfaRequest = {
      url: Constants.GET_MFA_REQUEST_URL + this.state.request_id,
      method: 'GET',
    }
    //alert(JSON.stringify(putMFAResponse));

    while (responseData.status == 'in-progress') {
      await this.sleep(5000);
      var getMfaResponse = await executeRestRequest(getMfaRequest);
      responseData = getMfaResponse.data
    }


    if (responseData.status == 'virtual-agent-page-loading-success') {
      this.state.show_spinner = false;
      this.setState({ step: "chat" })
      this.get_agent_message();
    } else {
      this.state.show_spinner = false;
      this.setState({ step: "start" })
      this.setState({ selected_fi: null })
      this.setState({ request_id: null })
      this.setState({ agent_message: null })
      this.setState({ error_message: "Technically difficulty. Please start chat again." })
    }

  }



  async send_message() {
    this.setState({ show_message_spinner: true });
    var payload = new Object();
    var data = new Object();
    var message = document.getElementById('message').value;
    data.message = message;
    data.request_id = this.state.request_id;
    payload.data = data;

    var sendUserMessageRequest = {
      url: Constants.SEND_USER_MESSAGE_URL,
      method: 'POST',
      payload: payload
    }
    var sendUserMessageResponse = await executeRestRequest(sendUserMessageRequest);
    document.getElementById('message').value = ""
    this.get_agent_message()
  }



  async get_agent_message() {
    var getAgentMessageRequest = {
      url: Constants.GET_AGENT_MESSAGE_URL + this.state.request_id,
      method: 'GET',
    }
    var getAgentMessageResponse = await executeRestRequest(getAgentMessageRequest);
    var responseData = getAgentMessageResponse.data
    var count = 0
    while (typeof responseData != 'undefined' && responseData.status == 'MessageNotFound' && count != 20) {
      await this.sleep(2000);
      getAgentMessageResponse = await executeRestRequest(getAgentMessageRequest);
      responseData = getAgentMessageResponse.data
      count++
    }
    //alert(JSON.stringify(getAgentMessageResponse.data))
    if (typeof responseData != 'undefined' && responseData.status == 'ok') {
      var message = responseData.agent_message.message;
      this.setState({ agent_message: message })
    }
    this.set_scroll_height()
    this.setState({ show_message_spinner: false });
  }



  async stop_chat() {
    if (this.state.request_id == null) {
      this.setState({ step: "start" });
      return;
    }
    var payload = new Object();
    var data = new Object();
    var message = "end";
    data.message = message;
    data.request_id = this.state.request_id;
    payload.data = data;

    var sendUserMessageRequest = {
      url: Constants.SEND_USER_MESSAGE_URL,
      method: 'POST',
      payload: payload
    }
    var sendUserMessageResponse = await executeRestRequest(sendUserMessageRequest);
    this.setState({ step: "start" })
    this.setState({ selected_fi: null })
    this.setState({ request_id: null })
    this.setState({ agent_message: null })
    this.setState({ error_message: null })
  }



  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }



  set_scroll_height() {
    var text_area = document.getElementById('chat_message')
    if (text_area == null) {
      return
    }
    text_area.scrollTop = text_area.scrollHeight;
  }

  setEmail = e => {
    this.setState({
      email: e.target.value
    });
  }

  setPassword = e => {
    this.setState({
      password: e.target.value
    });

  }



  render() {

    if (typeof this.state.fi_data == 'undefined') {
      return (
        <div> Technical difficulty in the service. </div>
      );
    }

    return (
      <div>
        <Navbar className="navigation__navbar navbar-dark bg-primary" light expand="md">
          <NavbarBrand href="#">Harvest Chat</NavbarBrand>
        </Navbar>

        <Container>

          {this.state.fi_data.map((data, index) => (
            <Row className="mt-3">
              <Col align="center">
                {this.state.step == 'start' ?
                  <Col> <Button onClick={(e) => this.start_chat(data.name)}  > {data.name}   Start Chat... </Button> </Col>
                  :
                  <Col> <Button disabled> {data.name}   Start Chat... </Button> </Col>
                }

              </Col>
            </Row>
          ))}


          <Row className="mt-3">
            <Col align="center">
              {this.state.error_message != null ?
                this.state.error_messagee
                : null
              }

            </Col>
          </Row>


          {this.state.show_spinner ?
            <Row className="mt-5">
              <Col align="center">
                <Spinner color="primary" animation="border" role="status"> </Spinner>
              </Col>
            </Row>
            :

            <div>
              {this.state.step == 'login' ?
                <form>
                  <Row className="mt-5">
                    <Col xl={1} >  <Label for="email">Email</Label>  </Col>
                    <Col> 
                      <Input type='email' name="email" id="email" value={this.state.email}
                        onChange={(e) => this.setEmail(e)} />
                    </Col>
                  </Row>
                  <Row className="mt-2">
                    <Col xl={1}>  <Label for="password" className="mr-sm-2">Password</Label> </Col>
                    <Col> 
                      <Input type='password' name="password" id="password" value={this.state.password}
                        onChange={(e) => this.setPassword(e)} />
                    </Col>
                  </Row>
                  <Row className="mt-2">
                    <Col xl={1}>    </Col>
                    <Col> <Button onClick={this.login}> Submit</Button> {' '}
                      <Button onClick={this.stop_chat} >Cancel Chat</Button>
                    </Col>
                  </Row>
                </form>
                :
                null
              }


              {this.state.step == 'authenticate' ?
                <form>
                  <Row className="mt-5">
                    <Col xl={1}>  <Label for="token" className="mr-sm-2">Token</Label> </Col>
                    <Col>  <Input type="text" name="token" id="token" /></Col>
                  </Row>
                  <Row className="mt-2">
                    <Col xl={1}>    </Col>
                    <Col> <Button onClick={this.send_token} >Submit</Button> {' '}
                      <Button onClick={this.stop_chat} >Cancel Chat</Button>
                    </Col>
                  </Row>
                </form>
                :
                null
              }


              {this.state.step == 'chat' ?
                <form>
                  <Row className="mt-5">
                    <Col align="center"> <Label for="chat" className="mr-sm-2">Chat</Label> </Col>
                  </Row>

                  {this.state.show_message_spinner ?
                    <Row className="mt-2">
                      <Col align="center">   <Spinner color="primary" animation="border" role="status"> </Spinner> </Col>
                    </Row>
                    :
                    null
                  }
                  <Row className="mt-2">
                    <Col>
                      <Input type="textarea" name="chat_message" id="chat_message"
                        style={{ height: 300, overflow: 'scroll', scrollTop: 300 }}
                        value={this.state.agent_message} disabled />
                    </Col>
                  </Row>
                  <Row className="mt-2">
                    <Col>  <Input type="textarea" name="message" id="message" /> </Col>
                  </Row>
                  <Row className="mt-2">
                    <Col align="rignt"> <Button onClick={this.send_message} >Submit</Button> {' '}
                      <Button onClick={this.stop_chat} >Stop Chat</Button>
                    </Col>
                  </Row>
                </form>
                :
                null
              }
            </div>
          }

        </Container>
      </div>
    );
  }
}



export default App;
