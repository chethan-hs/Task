from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait


class PayPalHelpCenterPage:
    URL = "https://www.paypal.com/us/smarthelp/home"

    def __init__(self, driver, num_seconds_wait_per_page):
        self.driver = driver
        self.num_seconds_wait_per_page = num_seconds_wait_per_page

    @staticmethod
    def _is_page_loaded():
        return EC.visibility_of_element_located((By.LINK_TEXT, 'Personal Help'))

    def is_page_loaded(self):
        try:
            WebDriverWait(self.driver, self.num_seconds_wait_per_page).until(
                PayPalHelpCenterPage._is_page_loaded())
        except TimeoutException:
            print("Timed out waiting for help center page to load")
            return False
        return True

    def click_chat_now_button(self):
        chat_now_button = self.driver.find_element_by_class_name("chat-question-card-btn")
        chat_now_button.click()

    def logout(self):
        logout_button = self.driver.find_element_by_id("header-logout")
        logout_button.click()

