from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait


class PayPalTwoFactorLogin:

    # URL = "https://www.paypal.com/authflow/twofactor"

    def __init__(self, driver, num_seconds_wait_per_page):
        self.driver = driver
        self.num_seconds_wait_per_page = num_seconds_wait_per_page

    def send_code_to_user(self):
        send_code_page = PayPalSendCodePage(self.driver)
        send_code_page.send_code()

    @staticmethod
    def read_code_from_user():
        code = PayPalVerifyCodePage.read_code_from_user()
        return code

    def send_user_provided_code(self, code):
        verify_code_page = PayPalVerifyCodePage(self.driver)
        verify_code_page.send_user_provided_code(code)

    def is_send_code_page_loaded(self):
        try:
            WebDriverWait(self.driver, self.num_seconds_wait_per_page).until(
                PayPalSendCodePage.is_loaded())
        except TimeoutException:
            print("Timed out waiting for login email page to load")
            return False
        return True

    def is_verify_code_page_loaded(self):
        try:
            WebDriverWait(self.driver, self.num_seconds_wait_per_page).until(
                PayPalVerifyCodePage.is_loaded())
        except TimeoutException:
            print("Timed out waiting for login password page to load")
            return False
        return True


class PayPalSendCodePage:

    def __init__(self, driver):
        self.driver = driver

    @staticmethod
    def is_loaded():
        return EC.visibility_of_element_located((By.CLASS_NAME, 'twofactorPage'))

    def send_code(self):
        continue_button = self.driver.find_element_by_class_name("vx_btn.vx_btn-block")
        continue_button.click()


class PayPalVerifyCodePage:

    def __init__(self, driver):
        self.driver = driver

    @staticmethod
    def is_loaded():
        return EC.visibility_of_element_located((By.NAME, 'otpCode'))

    @staticmethod
    def read_code_from_user():
        code = input("Enter the code")
        return code

    def send_user_provided_code(self, code):
        field_text = self.driver.find_element_by_name("otpCode")
        field_text.send_keys(code)
        continue_button = self.driver.find_element_by_class_name("vx_btn.vx_btn-block")
        continue_button.click()




