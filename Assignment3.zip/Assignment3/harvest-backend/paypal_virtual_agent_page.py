from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.keys import Keys
import time
from bs4 import BeautifulSoup


class PayPalVirtualAgent:

    def __init__(self, driver, num_seconds_wait_per_page):
        self.driver = driver
        self.num_seconds_wait_per_page = num_seconds_wait_per_page

    def send_message(self, message):
        chat_text_area = self.driver.find_element_by_id('inputSendChatMessage')
        time.sleep(2)
        chat_text_area.send_keys(str(message), Keys.ENTER)

    def read_message(self):
        time.sleep(4)
        print("Reading message from agent.")
        chat_node = self.driver.find_element_by_id('node-chat')
        chat_text = BeautifulSoup(chat_node.text, "html.parser")
        return str(chat_text)

    def close(self):
        close_link = self.driver.find_element_by_class_name('node-chat-cfwea2.e10zcry22')
        close_link.click()

    @staticmethod
    def _is_page_loaded():
        return EC.visibility_of_element_located((By.ID, 'inputSendChatMessage'))

    def is_page_loaded(self):
        try:
            WebDriverWait(self.driver, self.num_seconds_wait_per_page).until(
                PayPalVirtualAgent._is_page_loaded())
        except TimeoutException:
            print("Timed out waiting for virtual agent page to load")
            return False
        return True
