from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait


class PayPalSummaryPage:

    URL = "https://www.paypal.com/myaccount/summary/"

    def __init__(self, driver, num_seconds_wait_per_page):
        self.driver = driver
        self.num_seconds_wait_per_page = num_seconds_wait_per_page

    @staticmethod
    def _is_summary_page_loaded():
        return EC.visibility_of_element_located((By.LINK_TEXT, 'Summary'))

    def is_summary_page_loaded(self):
        try:
            WebDriverWait(self.driver, self.num_seconds_wait_per_page).until(
                PayPalSummaryPage._is_summary_page_loaded())
        except TimeoutException:
            print("Timed out waiting for summary page to load")
            return False
        return True

    def click_help_link(self):
        help_link = self.driver.find_element_by_link_text('Help')
        help_link.click()
        print("Clicked on Help Link.")

    @staticmethod
    def _is_help_menu_loaded():
        return EC.visibility_of_element_located((By.CLASS_NAME, 'minihelp-footer-link'))

    def is_help_menu_loaded(self):
        try:
            WebDriverWait(self.driver, self.num_seconds_wait_per_page).until(
                PayPalSummaryPage._is_help_menu_loaded())
        except TimeoutException:
            print("Timed out waiting for summary help menu to load")
            return False
        return True

    def click_help_center_link(self):
        help_center_link = self.driver.find_element_by_class_name("minihelp-footer-link")
        print("help_center_link=", help_center_link)
        help_center_link.click()
        print("Clicked on Help center Link.")

    def close_help_menu(self):
        close_help_menu = self.driver.find_element_by_class_name("context-close-icon")
        close_help_menu.click()

    def logout(self):
        try:
            logout_link = self.driver.find_element_by_id("header-logout")
            logout_link.click()
        except:
            print("Exception while logout from summary page.")

