from flask import Flask
from flask import request, jsonify
import uuid
from flask_cors import CORS
from threading import Thread
import threading
from harvest_queue import MFARequestQueue, MFAResponseQueue, RequestQueue, AgentMessageQueue, UserMessageQueue
from selenium import webdriver
from paypal import PayPal
import time

app = Flask(__name__)
CORS(app, supports_credentials=True)


@app.route("/", methods=["GET"])
def root():
    return "Backend is up and running!"


@app.route("/api/v1/financial-institutions", methods=["GET"])
def get_fi_list():
    response_data = {"data":[
                            {"name": "PayPal",
                             "isMFA": True}
                            ]
                    }
    return jsonify(response_data), 200


@app.route("/api/v1/account/login", methods=["POST"])
def login():
    request_data = request.get_json(force=True)
    login_data = request_data['data']
    response_data = dict()
    data = dict()
    if 'fi_name' not in login_data:
        data['status'] = "invalid request"
        response_data['data'] = data
        return jsonify(response_data), 400

    if 'email' not in login_data or 'password' not in login_data:
        data['status'] = "invalid credential"
        response_data['data'] = data
        return jsonify(response_data), 400

    request_id = str(uuid.uuid4())
    print(request_id)
    login_request = dict()
    login_request['email'] = login_data['email']
    login_request['password'] = login_data['password']
    login_request['fi_name'] = login_data['fi_name']
    login_request['request_id'] = request_id

    RequestQueue.add(login_request)

    response_data = dict()
    data = dict()
    data['request_id'] = request_id
    data['status'] = "login_request_sent"
    response_data['data'] = data

    return jsonify(response_data), 200


@app.route("/api/v1/mfa-request/<string:request_id>", methods=["GET"])
def get_mfa_request(request_id):
    mfa_request = MFARequestQueue.get(request_id)
    response_data = dict()
    data = dict()
    data['request_id'] = request_id
    if mfa_request is not None:
        data['mfa_request'] = mfa_request
        data['status'] = mfa_request['status']
    else:
        data['status'] = "in-progress"
    response_data['data'] = data
    return jsonify(response_data), 200


@app.route("/api/v1/mfa-response", methods=["POST"])
def put_mfa_response():
    request_data = request.get_json(force=True)
    mfa_response = request_data['data']
    MFAResponseQueue.add(mfa_response)
    response_data = dict()
    data = dict()
    data['status'] = "in-progress"
    response_data['data'] = data
    return jsonify(response_data), 200


@app.route("/api/v1/agent-message/<string:request_id>", methods=["GET"])
def get_agent_message(request_id):
    agent_message = AgentMessageQueue.get(request_id)
    response_data = dict()
    data = dict()
    data['request_id'] = request_id
    if agent_message is not None:
        data['agent_message'] = agent_message
        data['status'] = "ok"
    else:
        data['status'] = "MessageNotFound"
    response_data['data'] = data

    return jsonify(response_data), 200


@app.route("/api/v1/user-message", methods=["POST"])
def put_user_message():
    response_data = dict()
    data = dict()
    request_data = request.get_json(force=True)
    user_message = request_data['data']
    if user_message is None:
        data['status'] = "invalid request"
        response_data['data'] = data
        return jsonify(response_data), 400

    UserMessageQueue.add(user_message)
    data['status'] = "ok"
    response_data['data'] = data
    return jsonify(response_data), 200


def start_job():
    while True:
        print("Reading request from the queue.")
        size = RequestQueue.size()

        if size != 0:
            print("Request found, trying to start processing.")
            # start the thread to process the request
            Thread(target=start_process).start()
        else:
            print("Request not found, going for 5 seconds sleep.")
            time.sleep(5)


def start_process():
    login_request = RequestQueue.get()
    request_id = login_request['request_id']
    print("Started processing request with id:", request_id)
    chrome_driver_path = "C:\softwares\chromedriver.exe"
    email = login_request['email']
    password = login_request['password']
    num_seconds_wait_per_page = 20

    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument('--ignore-certificate-errors')
    # chrome_options.add_argument("--headless")
    chrome_options.add_argument("--window-size=1920x1080")
    chrome_options.add_argument("--test-type")

    driver = webdriver.Chrome(chrome_driver_path, chrome_options=chrome_options)

    pay_pal_account = PayPal(driver, email, password, num_seconds_wait_per_page)
    is_login_success = pay_pal_account.login()

    response_data = dict()
    response_data['request_id'] = request_id

    if not is_login_success:
        response_data['status'] = "login-failed"
        print("login-failed")
        MFARequestQueue.add(response_data)
        return
    else:
        response_data['status'] = "login-success"
        print("login-failed")
        MFARequestQueue.add(response_data)

    if not pay_pal_account.is_two_factor_page_loaded():
        response_data['status'] = "two-factor-page-loading-failed"
        print("two-factor-page-loading-failed")
        MFARequestQueue.add(response_data)
        return

    pay_pal_account.send_code_to_user()
    if not pay_pal_account.is_verify_code_page_loaded():
        response_data['status'] = "two-factor-verify-code-page-loading-failed"
        print("two-factor-verify-code-page-loading-failed")
        MFARequestQueue.add(response_data)
        return

    print("Waiting for user to provide token code for request_id:",request_id)
    mfa_user_response = MFAResponseQueue.get(request_id)
    while mfa_user_response is None:
        time.sleep(5)
        mfa_user_response = MFAResponseQueue.get(request_id)
        print("Waiting for user to provide token code.")

    print("Received user provided token code.")
    pay_pal_account.send_user_provided_code(mfa_user_response['token_id'])

    if not pay_pal_account.is_summary_page_loaded():
        response_data['status'] = "summary-page-loading-failed"
        print("summary-page-loading-failed")
        MFARequestQueue.add(response_data)
        return

    pay_pal_account.go_to_virtual_agent_page()
    if not pay_pal_account.is_virtual_agent_page_loaded():
        response_data['status'] = "virtual-agent-page-loading-failed"
        print("virtual-agent-page-loading-failed")
        MFARequestQueue.add(response_data)
        return
    else:
        response_data['status'] = "virtual-agent-page-loading-success"
        print("virtual-agent-page-loading-success")
        time.sleep(3)
        MFARequestQueue.add(response_data)
        agent_message = pay_pal_account.read_message_from_virtual_agent()
        response_message = dict()
        response_message['request_id'] = request_id
        response_message['message'] = agent_message
        response_message['status'] = "ok"
        AgentMessageQueue.add(response_message)
    exit_chat = False
    while True:
        message_list = UserMessageQueue.get(request_id)
        if message_list is not None:
            for user_message in message_list:
                message = user_message['message']
                if message == 'end':
                    print("Chat closing.")
                    pay_pal_account.close_virtual_agent()
                    pay_pal_account.logout_from_help_center_page()
                    pay_pal_account.logout_from_summary_page()
                    exit_chat = True
                    break
                else:
                    pay_pal_account.send_message_to_virtual_agent(message)
                    agent_message = pay_pal_account.read_message_from_virtual_agent()
                    response_message = dict()
                    response_message['request_id'] = request_id
                    response_message['message'] = agent_message
                    response_message['status'] = "ok"
                    AgentMessageQueue.add(response_message)
        else:
            time.sleep(3)
        if exit_chat:
            break

    print("Exit from chat.")
    return


if __name__ == "__main__":
    thread = threading.Thread(target=start_job)
    thread.daemon = True
    thread.start()
    app.run()









