from paypal_login_page import PayPalLoginPage
from paypay_two_factor_page import PayPalTwoFactorLogin
from paypal_summary_page import PayPalSummaryPage
from paypal_help_center_page import PayPalHelpCenterPage
from paypal_virtual_agent_page import PayPalVirtualAgent
import time


class PayPal:

    def __init__(self, driver, email, password, num_seconds_wait_per_page):
        self.email = email
        self.password = password
        self.driver = driver
        self.num_seconds_wait_per_page = num_seconds_wait_per_page

    def login(self):
        _driver = self.driver
        _num_seconds_wait_per_page = self.num_seconds_wait_per_page
        login_page = PayPalLoginPage(_driver, _num_seconds_wait_per_page)
        is_login_success = login_page.login(self.email, self.password)
        if not is_login_success:
            print("Login using email and password failed.")
            return False
        else:
            print("Login using email and password success.")
            return True

    def is_two_factor_page_loaded(self):
        _driver = self.driver
        _num_seconds_wait_per_page = self.num_seconds_wait_per_page
        two_factor_login_page = PayPalTwoFactorLogin(_driver, _num_seconds_wait_per_page)
        return two_factor_login_page.is_send_code_page_loaded()

    def send_code_to_user(self):
        _driver = self.driver
        _num_seconds_wait_per_page = self.num_seconds_wait_per_page
        two_factor_login_page = PayPalTwoFactorLogin(_driver, _num_seconds_wait_per_page)
        two_factor_login_page.send_code_to_user()

    def is_verify_code_page_loaded(self):
        _driver = self.driver
        _num_seconds_wait_per_page = self.num_seconds_wait_per_page
        two_factor_login_page = PayPalTwoFactorLogin(_driver, _num_seconds_wait_per_page)
        return two_factor_login_page.is_verify_code_page_loaded()

    def send_user_provided_code(self, code):
        _driver = self.driver
        _num_seconds_wait_per_page = self.num_seconds_wait_per_page
        two_factor_login_page = PayPalTwoFactorLogin(_driver, _num_seconds_wait_per_page)
        two_factor_login_page.send_user_provided_code(code)

    def is_summary_page_loaded(self):
        _driver = self.driver
        _num_seconds_wait_per_page = self.num_seconds_wait_per_page
        summary_page = PayPalSummaryPage(_driver, _num_seconds_wait_per_page)
        return summary_page.is_summary_page_loaded()

    def go_to_virtual_agent_page(self):
        _driver = self.driver
        _num_seconds_wait_per_page = self.num_seconds_wait_per_page
        summary_page = PayPalSummaryPage(_driver, _num_seconds_wait_per_page)
        summary_page.click_help_link()
        if not summary_page.is_help_menu_loaded():
            print("Summary page help menu is not loaded.")
            return False
        else:
            print("Summary page help menu is loaded.")

        summary_page.click_help_center_link()
        help_center_page = PayPalHelpCenterPage(_driver, _num_seconds_wait_per_page)

        time.sleep(_num_seconds_wait_per_page)
        # switch to next tab as help center page opens in new tab
        # New tabs will be the last object in window_handles
        self.driver.switch_to.window(self.driver.window_handles[-1])

        current_url = _driver.current_url
        print("current_url = ", current_url)
        if not help_center_page.is_page_loaded():
            print("HelpCenter page is not loaded.")
            current_url = _driver.current_url
            print("current_url = ", current_url)
            return False
        else:
            print("HelpCenter page is loaded.")
        help_center_page.click_chat_now_button()

    def is_virtual_agent_page_loaded(self):
        _driver = self.driver
        _num_seconds_wait_per_page = self.num_seconds_wait_per_page
        virtual_agent = PayPalVirtualAgent(_driver, _num_seconds_wait_per_page)
        if not virtual_agent.is_page_loaded():
            print("PayPal virtual agent is not loaded.")
            return False
        return True

    def send_message_to_virtual_agent(self, message):
        _driver = self.driver
        _num_seconds_wait_per_page = self.num_seconds_wait_per_page
        virtual_agent = PayPalVirtualAgent(_driver, _num_seconds_wait_per_page)
        virtual_agent.send_message(message)

    def read_message_from_virtual_agent(self):
        _driver = self.driver
        _num_seconds_wait_per_page = self.num_seconds_wait_per_page
        virtual_agent = PayPalVirtualAgent(_driver, _num_seconds_wait_per_page)
        message = virtual_agent.read_message()
        return message

    def close_virtual_agent(self):
        _driver = self.driver
        _num_seconds_wait_per_page = self.num_seconds_wait_per_page
        virtual_agent = PayPalVirtualAgent(_driver, _num_seconds_wait_per_page)
        virtual_agent.close()

    def logout_from_help_center_page(self):
        _driver = self.driver
        _num_seconds_wait_per_page = self.num_seconds_wait_per_page
        help_center_page = PayPalHelpCenterPage(_driver, _num_seconds_wait_per_page)
        help_center_page.logout()
        # switch back to main tab
        self.driver.switch_to.window(self.driver.window_handles[0])

    def logout_from_summary_page(self):
        _driver = self.driver
        _num_seconds_wait_per_page = self.num_seconds_wait_per_page
        summary_page = PayPalSummaryPage(_driver, _num_seconds_wait_per_page)
        time.sleep(3)
        summary_page.close_help_menu()
        time.sleep(2)
        summary_page.logout()
















