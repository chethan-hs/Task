from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait


class PayPalLoginPage:
    URL = "https://www.paypal.com/us/signin"

    def __init__(self, driver, num_seconds_wait_per_page):
        self.driver = driver
        self.num_seconds_wait_per_page = num_seconds_wait_per_page

    def login(self, email, password):
        pay_pal_login_email_page = PayPalLoginEmailPage(self.driver)
        pay_pal_login_email_page.load()
        if not self.is_login_email_page_loaded():
            print("PayPal Login email page not loaded.")
            return False
        pay_pal_login_email_page.login(email)

        pay_pal_login_password_page = PayPalLoginPasswordPage(self.driver)
        if not self.is_login_password_page_loaded():
            print("PayPal Login password page not loaded.")
            return False

        pay_pal_login_password_page.login(password)
        return True

    def is_login_email_page_loaded(self):
        try:
            WebDriverWait(self.driver, self.num_seconds_wait_per_page).until(
                PayPalLoginEmailPage.is_loaded())
        except TimeoutException:
            print("Timed out waiting for login email page to load")
            return False
        return True

    def is_login_password_page_loaded(self):
        try:
            WebDriverWait(self.driver, self.num_seconds_wait_per_page).until(
                PayPalLoginPasswordPage.is_loaded())
        except TimeoutException:
            print("Timed out waiting for login password page to load")
            return False
        return True


class PayPalLoginEmailPage:
    URL = "https://www.paypal.com/us/signin"

    def __init__(self, driver):
        self.driver = driver

    def load(self):
        self.driver.get(PayPalLoginEmailPage.URL)

    def login(self, email):
        email_field = self.driver.find_element_by_id('email')
        email_field.send_keys(email)

        next_button = self.driver.find_element_by_id('btnNext')
        next_button.click()

    @staticmethod
    def is_loaded():
        return EC.visibility_of_element_located((By.ID, 'email'))


class PayPalLoginPasswordPage:
    URL = "https://www.paypal.com/us/signin"

    def __init__(self, driver):
        self.driver = driver

    def login(self, password):
        driver = self.driver
        password_field = driver.find_element_by_id('password')
        password_field.send_keys(password)

        login_button = driver.find_element_by_id('btnLogin')
        login_button.click()

    @staticmethod
    def is_loaded():
        return EC.visibility_of_element_located((By.ID, 'password'))