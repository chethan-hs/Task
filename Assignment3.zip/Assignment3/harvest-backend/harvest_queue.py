
class RequestQueue:
    queue = list()

    @staticmethod
    def add(request):
        RequestQueue.queue.append(request)

    @staticmethod
    def get():
        if len(RequestQueue.queue) == 0:
            return None
        request = RequestQueue.queue[0]
        del RequestQueue.queue[0]
        return request

    @staticmethod
    def size():
        return len(RequestQueue.queue)

    @staticmethod
    def display():
        print("RequestQueue = ", RequestQueue.queue)


class ResponseQueue:
    queue = dict()

    @staticmethod
    def add(response):
        request_id = response['request_id']
        ResponseQueue.queue[request_id] = response
        ResponseQueue.display()

    @staticmethod
    def get(request_id):
        response = ResponseQueue.queue.get(request_id)
        if response is not None:
            del ResponseQueue.queue[request_id]
        ResponseQueue.display()
        return response

    @staticmethod
    def display():
        print("ResponseQueue = ", ResponseQueue.queue)


class MFARequestQueue:

    # if end site ask for any security data then request will be added in this queue
    queue = dict()

    @staticmethod
    def add(mfa_request):
        request_id = mfa_request['request_id']
        MFARequestQueue.queue[request_id] = mfa_request

    # user reads this request
    @staticmethod
    def get(request_id):
        request = MFARequestQueue.queue.get(request_id)
        if request is not None:
            del MFARequestQueue.queue[request_id]
        return request

    @staticmethod
    def display():
        print("MFARequestQueue = ", MFARequestQueue.queue)


class MFAResponseQueue:

    # When user provides the security data, response will be added to this queue
    queue = dict()

    @staticmethod
    def add(mfa_response):
        request_id = mfa_response['request_id']
        MFAResponseQueue.queue[request_id] = mfa_response

    # System reads user response
    @staticmethod
    def get(request_id):

        mfa_response = MFAResponseQueue.queue.get(request_id)
        if mfa_response is not None:
            del MFAResponseQueue.queue[request_id]
        return mfa_response

    @staticmethod
    def display():
        print("MFAResponseQueue = ", MFAResponseQueue.queue)


class AgentMessageQueue:
    queue = dict()

    @staticmethod
    def add(message):
        request_id = message['request_id']
        AgentMessageQueue.queue[request_id] = message
        AgentMessageQueue.display()

    @staticmethod
    def get(request_id):
        agent_message = AgentMessageQueue.queue.get(request_id)
        if agent_message is not None:
            del AgentMessageQueue.queue[request_id]
        AgentMessageQueue.display()
        return agent_message

    @staticmethod
    def display():
        print("AgentMessageQueue = ", AgentMessageQueue.queue)


class UserMessageQueue:
    queue = dict()

    @staticmethod
    def add(message):
        request_id = message['request_id']
        if request_id not in UserMessageQueue.queue:
            message_list = list()
            UserMessageQueue.queue[request_id] = message_list
        message_list = UserMessageQueue.queue[request_id]
        message_list.append(message)
        UserMessageQueue.display()

    @staticmethod
    def get(request_id):
        message_list = UserMessageQueue.queue.get(request_id)
        if message_list is not None:
            del UserMessageQueue.queue[request_id]
        UserMessageQueue.display()
        return message_list

    @staticmethod
    def display():
        print("UserMessageQueue = ", UserMessageQueue.queue)